# Übungsaufgaben – Fachinformatiker Anwendungsentwicklung

## Projektstruktur

```
├── java/
│   ├── Aufgabe01_HalloWelt.java
│   ├── Aufgabe02_Benutzereingabe.java
│   ├── Aufgabe03_Methoden.java
│   ├── Aufgabe04_Fakultaet.java
│   ├── Aufgabe05_Quadrat.java
│   ├── Aufgabe06_Dreieck.java
│   ├── Aufgabe07_PascalschesDreieck.java
│   ├── Aufgabe08_ArraySortieren.java
│   ├── Aufgabe09_Quadratzahlen.java
│   ├── Aufgabe10_Zahlensysteme.java
│   ├── Aufgabe11_Steuerrechner.java
│   ├── Aufgabe12_Sparbuch.java
│   └── aufgabe13_polymorphismus/
│       ├── Angestellter.java
│       ├── Sekretaerin.java
│       ├── Verkaeufer.java
│       ├── Manager.java
│       └── Aufgabe13_TestPolymorphismus.java
│
└── javascript/
    ├── aufgabe01_summe.js
    ├── aufgabe02_wuerfelspiele.js
    ├── aufgabe03_todo.html
    ├── aufgabe04_greeting.html
    ├── greeting.json
    └── aufgabe05_ajax/
        ├── index.html
        ├── ajax.html
        └── script.js
```

## Java-Aufgaben (1–13)

Alle Java-Dateien lassen sich einzeln mit `javac` kompilieren und mit `java` ausführen:

```bash
javac Aufgabe01_HalloWelt.java
java Aufgabe01_HalloWelt
```

Für Aufgabe 13 (Polymorphismus) müssen alle fünf Dateien im selben Verzeichnis liegen:

```bash
cd java/aufgabe13_polymorphismus/
javac *.java
java Aufgabe13_TestPolymorphismus
```

## JavaScript-Aufgaben (1–5)

- **Aufgabe 1 und 2** sind reine JS-Dateien, ausführbar in der Browser-Konsole oder mit Node.js.
- **Aufgabe 3** (ToDo-Liste) kann direkt im Browser geöffnet werden.
- **Aufgabe 4 und 5** erfordern einen HTTP-Server (z.B. Apache oder `python -m http.server`), da AJAX-Requests über das `file://`-Protokoll blockiert werden.

## Hinweise

- Kein Einsatz von vorgefertigten Sortieralgorithmen in Aufgabe 8 (eigener Bubble Sort).
- Aufgabe 10 wandelt Zahlensysteme manuell um (kein Integer.parseInt).
- Aufgabe 13 nutzt Polymorphismus ohne instanceof-Abfragen im Testprogramm.
